<?php
    include '../Banco/DB/conexao.php';
    include '../Banco/DB/crud.php';
    //leitura dos dados da postagem
    $CRUD = new CRUD;
    if(!empty($_GET["id"])){
        foreach($CRUD->readposts() as $dadosdoid):
            if($dadosdoid['id'] == $_GET["id"]):
                $titulopost = $dadosdoid['titulo'];
                $iconepost = $dadosdoid['icone'];
                $descricaopost = $dadosdoid['descricao'];
                $visuatual = $dadosdoid['visu'];
            endif;
        endforeach;
    }else{
        foreach($CRUD->readblogs() as $dadosdoid):
            if($dadosdoid['id'] == $_GET["id2"]):
                $titulopost = $dadosdoid['titulo'];
                $iconepost = $dadosdoid['icone'];
                $descricaopost = $dadosdoid['descricao'];
                $visuatual = $dadosdoid['visu'];
            endif;
        endforeach;
    }

    if(!empty($_GET["id2"])){
        $idblog = $_GET["id2"];
        $visu = $visuatual+1;
        $CRUD->addvisudicas($idblog, $visu);
    }

    if(!empty($_GET["id"])){
        $idcurso = $_GET["id"];
        $visu = $visuatual+1;
        $CRUD->addvisu($idcurso, $visu);
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Assunto</title>
    <link rel="shortcut icon" href="../img/fav.png">
    <meta charset="utf-8">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!--Customização-->
    <link rel="stylesheet" href="../css/custom.css">
    <!-- Fontes -->
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Heebo&display=swap" rel="stylesheet">

</head>

<body>
    <!-- C A B E Ç A L H O -->
    <nav class="center navegacao red darken-1">
        <a href=".." class="brand-logo center show-on-med-and-up">Bilingual</a>
        <a href="#" data-target="slide-out" class="sidenav-trigger btn-floating pulse medium red darken-1 z-depth-0 white-text"><i class="white-text large material-icons left show-on-small hide-on-large-only">menu</i></a>
    </nav>

    <!-- SIDE NAV -->
    <ul id="slide-out" class="sidenav">
        <li><div class="user-view">
          <div class="background">
            <img src="../img/sliderred.jpg" alt="" class="cursor-pointer">
          </div>
          <a href="#"><img src="../img/logo.jpeg" alt="" class="circle cursor-pointer"></a>
          <br>
        </div>
        <div class="collection">
            <a href="dicas.php" class="red-text text-lighten-1 waves-effect waves-light collection-item"><i class="material-icons left">create</i>Dicas</a>
            <a href="curso.php" class="red-text text-lighten-1 waves-effect waves-light collection-item active"><i class="material-icons left">import_contacts</i>Curso de inglês</a>
            <a href="sobre.php" class="red-text text-lighten-1 waves-effect waves-light collection-item"><i class="material-icons left">import_contacts</i>Sobre mim! (Criador)</a>
            <br>
        </div>
    </ul>


    <!-- C O N T E Ú D O -->

    <div class="row wrapper">
        <aside class="lado col s12 m4 l3 center hide-on-med-and-down">
            <h4 class="red-text text-lighten-2">Welcome!</h4>
            <a href="#"><img src="../img/logo.jpeg" alt="" class="circle z-depth-1 tooltipped" data-position="bottom" data-tooltip="Clique para editar o perfil." width="60%"></a>
            <div class="collection">
                <a href="dicas.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped" data-position="right" data-tooltip="Bilingual dicas"><i class="material-icons left">create</i>Dicas</a>
                <br>
                <a href="curso.php" class="red-text text-lighten-1 waves-effect waves-light collection-item active tooltipped" data-position="right" data-tooltip="Curso completo"><i class="material-icons left">import_contacts</i>Curso de inglês</a>
                <br>
                <a href="sobre.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped" data-position="right" data-tooltip="Curso completo"><i class="material-icons left">import_contacts</i>Sobre mim! (Criador)</a>
            </div>
        </aside>
        <div class="col s12 m12 l9 center">
            <br>
            <i class="material-icons large red-text"><?php echo $iconepost;?></i>
            <?php echo $descricaopost;?>
            <br>
            <?php
            if(isset($_GET['id']) && $idcurso < 48){ 
            ?>
                <a style="margin-bottom: 30px; border-radius: 10px;" href="assunto.php?id=<?php echo $idcurso+1?>" class="btn large waves-light waves-light red darken-2"><i class="material-icons right">arrow_forward_ios</i>Próxima aula</a>
            <?php }else if(isset($_GET['id2']) && $idblog < 4){ ?>
                <a style="margin-bottom: 30px; border-radius: 10px;" href="assunto.php?id2=<?php echo $idblog+1?>" class="btn large waves-light waves-light red darken-2"><i class="material-icons right">arrow_forward_ios</i>Próxima dica</a>
            <?php } ?>
        </div>
    </div>

    <?php include'../includes/rodape.php' ?>

    <!--Jquery-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <!--Inicializações-->
    <script>
        $(document).ready(function(){
            $('.sidenav').sidenav();
        });

        speaks = [
          {
            "name": "Alex",
            "lang": "en-US"
          }
        ];

        function falar(id) {
            var texto = document.getElementById(id);
            const msg = new SpeechSynthesisUtterance();
            msg.volume = 1; // 0 to 1
            msg.rate = 0.6; // 0.1 to 10
            msg.pitch = 1; // 0 to 2
            msg.text  = texto.textContent;
            const voice = speaks[0];
            console.log('Voice: ${voice.name} and Lang: ${voice.lang}');
            msg.voiceURI = voice.name;
            msg.lang = voice.lang;
            speechSynthesis.speak(msg);
        }

    </script>
</body>

</html>