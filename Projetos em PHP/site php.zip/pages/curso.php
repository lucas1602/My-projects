<?php
    require_once '../Banco/DB/conexao.php';
    require_once '../Banco/DB/crud.php';
    $CRUD = new CRUD;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Curso de inglês</title>
    <link rel="shortcut icon" href="../img/fav.png">
    <meta charset="utf-8">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!--Customização-->
    <link rel="stylesheet" href="../css/custom.css">
    <!-- Fontes -->
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap" rel="stylesheet">
</head>

<body>
    <!-- C A B E Ç A L H O -->
    <nav class="center navegacao red darken-1">
        <a href=".." class="brand-logo center show-on-med-and-up">Bilingual</a>
        <a href="#" data-target="slide-out" class="sidenav-trigger btn-floating pulse medium red darken-1 z-depth-0 white-text"><i class="white-text large material-icons left show-on-small hide-on-med-and-up">menu</i></a>
    </nav>

    <!-- SIDE NAV -->
    <ul id="slide-out" class="sidenav">
        <li><div class="user-view">
          <div class="background">
            <img src="../img/sliderred.jpg" alt="" class="cursor-pointer">
          </div>
          <a href="#user"><img src="../img/logo.jpeg" alt="" class="circle cursor-pointer"></a>
          <br>
        </div>
        <div class="collection">
            <a href="dicas.php" class="red-text text-lighten-1 waves-effect waves-light collection-item"><i class="material-icons left">create</i>Dicas</a>
            <a href="curso.php" class="red-text text-lighten-1 waves-effect waves-light collection-item active"><i class="material-icons left">import_contacts</i>Curso de inglês</a>
            <a href="sobre.php" class="red-text text-lighten-1 waves-effect waves-light collection-item"><i class="material-icons left">sentiment_satisfied_alt</i>Sobre mim! (Criador)</a>
        </div>
    </ul>


    <!-- C O N T E Ú D O -->

    <div class="row wrapper">
        <aside class="lado col s12 m4 l3 center hide-on-small-only">
            <h4 class="red-text text-lighten-2">Welcome!</h4>
            <a href="#"><img src="../img/logo.jpeg" alt="" class="circle z-depth-1 tooltipped" data-position="bottom" data-tooltip="Obrigado por nos visitar :)" width="60%"></a>
            <div class="collection">
                <a href="dicas.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped" data-position="right" data-tooltip="Bilingual dicas"><i class="material-icons left">create</i>Dicas</a>
                <br>
                <a href="curso.php" class="red-text text-lighten-1 waves-effect waves-light collection-item active tooltipped" data-position="right" data-tooltip="Curso completo"><i class="material-icons left">import_contacts</i>Curso de inglês</a>
                <br>
                <a href="sobre.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped" data-position="right" data-tooltip="Sobre mim"><i class="material-icons left">sentiment_satisfied_alt</i>Sobre mim! (Criador)</a>
                <br>
            </div>
        </aside>
        <div class="col s12 m8 l9 center">
            <h4 class="red-text text-lighten-2" style="padding: 3px;">Aulas</h4>
            <i class="material-icons large red-text">menu_book</i><h6>Olá, tudo bem?</h6>
            <p>Nessa página você pode acessar o curso de inglês completo e organizado! :)</p>
            <br>
            <a style="border-radius: 20px" class="btn waves-effect waves-light red darken-1" href="sobre.php">Saiba sobre mim!</a>
            <br>
            <h5 class="red-text text-darken-4">Ajude a manter minha página ativa em uma hospedagem melhor:</h5>
            <br>
            <div style="width: 100%; display: flex; align-items: center; justify-content: space-around;">
              <form action="https://www.paypal.com/donate" method="post" target="_top">
                <input type="hidden" name="cmd" value="_donations" />
                <input type="hidden" name="business" value="4Q74QSJ8BTHUA" />
                <input type="hidden" name="item_name" value="Mantenha meu site ativo e me motive a continuar!" />
                <input type="hidden" name="currency_code" value="BRL" />
                <input type="image" src="https://www.paypalobjects.com/pt_BR/BR/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Faça doações com o botão do PayPal" />
                <img alt="" border="0" src="https://www.paypal.com/pt_BR/i/scr/pixel.gif" width="1" height="1" />
              </form>
              <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
              <form action="https://pagseguro.uol.com.br/checkout/v2/donation.html" method="post">
                <!-- NÃO EDITE OS COMANDOS DAS LINHAS ABAIXO -->
                <input type="hidden" name="currency" value="BRL" />
                <input type="hidden" name="receiverEmail" value="alanlucas7301@gmail.com" />
                <input type="hidden" name="iot" value="button" />
                <input type="image" src="https://stc.pagseguro.uol.com.br/public/img/botoes/doacoes/120x53-doar.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
              </form>
              <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
              <div>
                <a style="border-radius: 20px;" class="btn waves-effect waves-light purple darken-1 modal-trigger" href="#modal1">Nubank</a>
                <p>Transf. Dep.</p>
              </div>
            </div>
            
              <div id="modal1" class="modal">
                <div class="modal-content">
                  <h4>Dados nubank:</h4>
                  <p>Por questão de segurança, envie um e-mail para alanlucas7301@gmail.com e solicite os dados, por favor!</p>
                </div>
                <div class="modal-footer">
                  <a href="#!" class="modal-close waves-effect waves-green btn-flat">Fechar</a>
                </div>
              </div>
            <br><br><br>
        <?php 
        $numitens = 6;
        $nlinhas = $CRUD->nlinhas();
        $paginas = ceil($nlinhas/$numitens);

        ?>
        <?php if(empty($_GET['comeco'])){ $_GET['comeco'] = 1;}?>
        <?php foreach($CRUD->readposts() as $post): ?>
            <?php if($_GET['comeco'] == 1):?>
                <?php for($i = 1; $i <= 6; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                		      <div class="card white">
                		        <div class="card-content grey-text text-darken-4">
                		          <span class="card-title"><?php echo $post['titulo'];?></span>
                		          <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                		          <p class="truncate"><?php echo $post['sobre'];?></p>
                              <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                		        </div>
                		        <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                		          <a></a>
                		        </div>
                		      </div>  	
                      	</div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 2):?>
                <?php for($i = 7; $i <= 12; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 3):?>
                <?php for($i = 13; $i <= 18; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 4):?>
                <?php for($i = 19; $i <= 24; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 5):?>
                <?php for($i = 25; $i <= 30; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 6):?>
                <?php for($i = 31; $i <= 36; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 7):?>
                <?php for($i = 37; $i <= 42; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
            <?php if($_GET['comeco'] == 8):?>
                <?php for($i = 43; $i <= 48; $i++):?>
                    <?php if($post['id'] == $i): ?>
                        <div class="col s12 m12 l12 xl4">
                              <div class="card white">
                                <div class="card-content grey-text text-darken-4">
                                  <span class="card-title"><?php echo $post['titulo'];?></span>
                                  <i class="material-icons large red-text"><?php echo $post['icone'];?></i>
                                  <p class="truncate"><?php echo $post['sobre'];?></p>
                                  <a href="assunto.php?id=<?php echo $post['id'];?>" class="blue-text">Ler mais</a>
                                </div>
                                <div class="card-action">
                                  <a class="left grey-text text-darken-4"><i class="material-icons left">visibility</i><?php echo $post['visu'];?></a>
                                  <a></a>
                                </div>
                              </div>    
                        </div>
                      <?php endif;?>
                  <?php endfor;?>
            <?php endif;?>
        <?php endforeach;?>
        <div class="col s12">
          <br>
          <ul class="pagination" style="margin-bottom: 50px;">
            <?php for($i = 1; $i <=  $paginas; $i++) { 
                if($_GET['comeco'] == $i){
                    $estilo = "class=\"waves-effect active\"";
                }else{
                    $estilo = "class=\"waves-effect\"";
                }
                ?>
                <li <?php echo $estilo; ?> ><a href="curso.php?comeco=<?php echo $i;?>"><?php echo $i?></a></li>
            <?php } ?>
          </ul>
        </div>
        </div>
    </div>

    <?php include'../includes/rodape.php' ?>

    <!--Jquery-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <!--Inicializações-->
    <script>
        $(document).ready(function(){
            $('.sidenav').sidenav();
            $('.tooltipped').tooltip();
            $('.modal').modal();
        });
    </script>
</body>

</html>