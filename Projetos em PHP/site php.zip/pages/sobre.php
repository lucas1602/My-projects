<!DOCTYPE html>
<html>
<head>
    <title>Sobre</title>
    <link rel="shortcut icon" href="../img/fav.png">
    <meta charset="utf-8"> 
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!--Customização-->
    <link rel="stylesheet" href="../css/custom.css">
    <!-- Fontes -->
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap" rel="stylesheet">
</head>

<body>
    <!-- C A B E Ç A L H O -->
    <nav class="center navegacao red darken-1">
        <a href=".." class="brand-logo center show-on-med-and-up">Bilingual</a>
        <a href="#" data-target="slide-out" class="sidenav-trigger btn-floating pulse medium red darken-1 z-depth-0 white-text"><i class="white-text large material-icons left show-on-small hide-on-med-and-up">menu</i></a>
    </nav>
    
    <!-- SIDE NAV -->
    <ul id="slide-out" class="sidenav">
        <li><div class="user-view">
          <div class="background">
            <img src="../img/sliderred.jpg" alt="" class="cursor-pointer">
          </div>
          <a href="#user"><img src="../img/logo.jpeg" alt="" class="circle cursor-pointer"></a>
          <br>
        </div>
        <div class="collection">
            <a href="dicas.php" class="red-text text-lighten-1 waves-effect waves-light collection-item"><i class="material-icons left">create</i>Dicas</a>
            <a href="curso.php" class="red-text text-lighten-1 waves-effect waves-light collection-item"><i class="material-icons left">import_contacts</i>Curso de inglês</a>
            <a href="sobre.php" class="red-text text-lighten-1 waves-effect waves-light collection-item active"><i class="material-icons left">sentiment_satisfied_alt</i>Sobre mim! (Criador)</a>
        </div>
    </ul>

    <!-- C O N T E Ú D O -->

    <div class="row wrapper">
        <aside class="lado col s12 m4 l3 center hide-on-small-only">
            <h4 class="red-text text-lighten-2">Welcome!</h4>
            <a href="#"><img src="../img/logo.jpeg" alt="" class="circle z-depth-1 tooltipped" data-position="bottom" data-tooltip="Obrigado por nos visitar :)" width="60%"></a>
            <div class="collection">
                <a href="dicas.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped" data-position="right" data-tooltip="Bilingual Dicas"><i class="material-icons left">create</i>Dicas</a>
                <br>
                <a href="curso.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped" data-position="right" data-tooltip="Curso completo"><i class="material-icons left">import_contacts</i>Curso de inglês</a>
                <br>
                <a href="sobre.php" class="red-text text-lighten-1 waves-effect waves-light collection-item tooltipped active" data-position="right" data-tooltip="Sobre mim"><i class="material-icons left">sentiment_satisfied_alt</i>Sobre mim! (Criador)</a>
                <br>
            </div>
        </aside>
        <div class="col s12 m8 l9 center">
            <h4 class="red-text text-lighten-2" style="padding: 3px;">Sobre mim! (Criador)</h4>
            <i class="material-icons large red-text">assistant_photo</i><h6>Oi, tudo bem?</h6>
            <p>Irei me apresentar para você aqui!</p>
            <br>
            <h5 class="red-text text-darken-4">Ajude a manter minha página ativa em uma hospedagem melhor:</h5>
            <br>
            <div style="width: 100%; display: flex; align-items: center; justify-content: space-around;">
              <form action="https://www.paypal.com/donate" method="post" target="_top">
                <input type="hidden" name="cmd" value="_donations" />
                <input type="hidden" name="business" value="4Q74QSJ8BTHUA" />
                <input type="hidden" name="item_name" value="Mantenha meu site ativo e me motive a continuar!" />
                <input type="hidden" name="currency_code" value="BRL" />
                <input type="image" src="https://www.paypalobjects.com/pt_BR/BR/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Faça doações com o botão do PayPal" />
                <img alt="" border="0" src="https://www.paypal.com/pt_BR/i/scr/pixel.gif" width="1" height="1" />
              </form>
              <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
              <form action="https://pagseguro.uol.com.br/checkout/v2/donation.html" method="post">
                <!-- NÃO EDITE OS COMANDOS DAS LINHAS ABAIXO -->
                <input type="hidden" name="currency" value="BRL" />
                <input type="hidden" name="receiverEmail" value="alanlucas7301@gmail.com" />
                <input type="hidden" name="iot" value="button" />
                <input type="image" src="https://stc.pagseguro.uol.com.br/public/img/botoes/doacoes/120x53-doar.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
              </form>
              <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
              <div>
                <a style="border-radius: 20px;" class="btn waves-effect waves-light purple darken-1 modal-trigger" href="#modal1">Nubank</a>
                <p>Transf. Dep.</p>
              </div>
            </div>
            <div id="modal1" class="modal">
                <div class="modal-content">
                  <h4>Dados nubank:</h4>
                  <p>Por questão de segurança, envie um e-mail para alanlucas7301@gmail.com e solicite os dados, por favor!</p>
                </div>
                <div class="modal-footer">
                  <a href="#!" class="modal-close waves-effect waves-green btn-flat">Fechar</a>
                </div>
            </div>
            <br>
            <h4>Lucas!</h4>
            <br>
            <div style="width: 100%; display: flex; justify-content: center;">
            <p style="text-align: justify; width: 80%; font-size: 1.2rem;">    Talvez vocês já tenham percebido, mas meu nome é Lucas e moro em Pernambuco. 
Após terminar o ensino médio ainda sem saber o que eu queria, me inscrevi no meu primeiro vestibular do IFPE e escolhi o curso de automação industrial, pois me falaram que ele tinha muitas matérias de cálculos, então como eu era apaixonado por números, fiz e passei.
Antes do resultado eu fiquei super chateado porque eu não entendia sobre cotas e eu não tinha selecionado essa opção...E pelo grande motivo de eu ser inseguro por sempre ter estudado em escola pública, achei que não iria passar :(.
Mas quando saiu o resultado, foi uma grande surpresa eu ter ficado em 5° lugar xD.
No curso, as duas matérias que eu mais gostava do primeiro período eram matemática e informática, pois finalmente eu iria entender mais coisas além do básico que eu mexia nas Lan houses :D.
O segundo período chegou e tivemos uma matéria de lógica de programação em C. Automaticamente eu lembrei do tempo em que eu baixava a Unity 3D e acompanhava os tutoriais do Youtube pra criar pequenos jogos. Eu entendia algumas coisas, pois nessa época eu já sabia bem inglês e eu conseguia "ler" mais ou menos o que o código fazia, só não sabia o que esse código era 😂.

A matéria de programação foi o que fez meus olhos brilharem, e meu coração disparar. TODO o meu tempo livre em casa era para acompanhar tutoriais no YouTube sobre programação, projetos, aplicativos, jogos, programas e etc...
Quando eu passei de período, eu não queria de jeito nenhum me afastar daquela matéria, então eu resolvi fazer a prova para ser monitor e ajudar os outros alunos com programação, pois ela era considerada o terror do segundo período.

Fui monitor durante quase três semestres, mas eu quis sair da monitoria e ir aprender mais, então fui fazer projetos de extensão. Neles aprendi a desenvolver noções básicas de combinação de cores, criação de lógicas para aplicar em projetos reais, banco de dados e etc..
Fiquei totalmente encantado com aquelas coisas que eu criava, o sentimento era incomparável!

Tempo se passou e eu não podia mais só ficar naquilo...Aliás eu tinha que arrumar um emprego, eu precisava de um estágio! Aí foi quando consegui passar no estágio do próprio campus do IFPE, mas me decepcionei e não era o que eu esperava :( além de ter sido cancelado devido a pandemia do covid-19 que apareceu bem na hora.
No tempo do covid-19 eu continuei nos projetos remotamente, e no meu tempo livre eu só jogava jogava e jogava. Foi quando eu pensei: "Cara, eu sou uma pessoa cheia de talentos e qualidades, por que estou gastando meu tempo ao invés de fazer algo produtivo?!".
E foi aí que começou minha maratona de cursos atrás de cursos em plataformas online.
HTML, CSS, JS, PHP, PHP Orientado a objetos, SQL, React, React Native, Expo, Bootstrap, Materialize css, Design responsivo, e etc.
Mas foram MUITOS cursos e conhecimentos adquiridos em mais ou menos 7 ou 8 meses de estudos.
Criei alguns projetos que estavam na minha máquina(antes de eu perder todos os arquivos com um problema que eu tive no meu computador ;(.)
E então foquei no meu site para ensinar inglês para os meus amigos principalmente. Todos eles amaram e disseram que era hora de eu abrir ele para todo mundo porque a qualidade está incrível (eu duvido, pois tem muito o que melhorar).
Mas eu tive que arrumar um emprego para ajudar em casa, então fiquei com muito pouco tempo para me dedicar ao que eu gosto.
Mas nesse tempo de feriado (natal), eu consegui finalizar uma versão "aceitável" para liberar para as pessoas.
Porém... Minha condição financeira não é muito boa para eu conseguir pagar uma hospedagem e domínio, e por esse motivo eu estou liberando ele nessa gratuita que encontrei 🙏.

Atualmente eu dou aulas fixas semanais a duas pessoas de lógica de programação, HTML e CSS. Nesse tempo é a melhor parte do meu dia porque eu ensino com uma empolgação tão grande, e é tão bom quando a pessoa entende e consegue fazer os exercícios que eu passo, é muito gratificante, queria poder fazer isso para mais pessoas...

Ah, lembrando que eu só vim conhecer o github depois de perder meus arquivos...que azar! Mas tudo bem, vou começar a criar meus repositórios em breve quando eu tiver tempo (SE eu tiver tempo), meu trabalho pega 80% do meu dia 😞.
Outra coisa também é que sim, eu pretendo fazer faculdade na área, porém não sei quando, mas espero que seja em breve...

Enfim, foi um grande resumo sobre minha vida e história de como eu comecei a me interessar por essa área maravilhosa.
Espero não ter tomado muito o seu tempo, e se você leu até aqui, meu grande obrigado.

Aproveitem o site!!

PS: Toda a lógica de programação, design e conteúdo foram criados por mim, eu falo "equipe bilingual" não sei o porquê. 😂
<br>
<br></p>
</div>
        </div>
    </div>

    <?php include'../includes/rodape.php' ?>

    <!--Jquery-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <!--Inicializações-->
    <script>
        $(document).ready(function(){
            $('.sidenav').sidenav();
            $('.tooltipped').tooltip();
            $('.modal').modal();
        });
    </script>
</body>

</html>