<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, inicial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="stylesheet" href="css/aos.css">
    <script src="js/Jquery3.4.1.min.js"></script>
    <title>Praia beach</title>
</head>

<body>
    <div class="principal" id="inicio">
        <div class="navbar" data-aos="zoom-in">
            <divl class="logo">
                <a href="#">Praia Beach</a>
            </divl>
            <div class="nav_items">
                <ul>
                    <li><a href="#servicos">Serviços</a></li>
                </ul>
            </div>
        </div>

        <div class="banner_image">
            <div class="banner_conteudo" data-aos="zoom-in">
                <h1>A calma do mar e a brisa do horizonte<br>
                    <span>Formam um lugar tranquilo de pura renovação espiritual.</span>
                </h1>
                <p>Estar em contato com a praia é se deparar com uma das maiores belezas da natureza.</p>
                <a href="#" class="chame">Contate-nos agora!</a>
            </div>
        </div>

        <div class="servicos" id="servicos">
            <h1 class="titulo" data-aos="fade-up" data-aos-duration="1000">Nossos serviços</h1>
            <p data-aos="fade-up" data-aos-duration="1000">Texto aleatório escrito com objetivo de preencher o paragrafo para que ele fique visualmente bom Texto
                aleatório escrito com objetivo de preencher o paragrafo para que ele fique visualmente bom Texto
                aleatório escrito com objetivo de preencher o paragrafo para que ele fique visualmente bom</p>
            <div class="outros_servicos">
                <div class="outros_servicos_item">
                    <img src="img/bug.jpg" alt="servicos_imagem" data-aos="flip-up">
                    <h3 data-aos="fade-up" data-aos-duration="1000">Passeio de bug</h3>
                    <p data-aos="fade-up" data-aos-duration="1000">Texto aleatório escrito com objetivo de preencher o paragrafo para que ele fique visualmente bom
                    </p>
                </div>
                <div class="outros_servicos_item">
                    <img src="img/jangada.jpg" alt="servicos_imagem" data-aos="flip-up">
                    <h3 data-aos="fade-up" data-aos-duration="1000">Jangada</h3>
                    <p data-aos="fade-up" data-aos-duration="1000">Texto aleatório escrito com objetivo de preencher o paragrafo para que ele fique visualmente bom
                    </p>
                </div>
                <div class="outros_servicos_item">
                    <img src="img/hospedagem.jpg" alt="servicos_imagem" data-aos="flip-up">
                    <h3 data-aos="fade-up" data-aos-duration="1000">Hospedagem</h3>
                    <p data-aos="fade-up" data-aos-duration="1000">Texto aleatório escrito com objetivo de preencher o paragrafo para que ele fique visualmente bom
                    </p>
                </div>
            </div>
        </div>

        <div class="rodape">
            <a href="#">praiabeach@gmail.com (81) 99999-9999 ipojuca rua tal tal próximo a tal</a>
        </div>
    </div>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script>
        $(document).ready(function () {
            // AOS Instance
            AOS.init();
        });
    </script>
</body>

</html>