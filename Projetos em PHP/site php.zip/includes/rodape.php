<!-- RODAPE -->
<footer class="page-footer red darken-4" style="margin-top: 50px";>
  <div class="container">
    <div class="row">
      <div class="col l6 s12">
        <h5 class="white-text">Saiba mais</h5>
        <p class="grey-text text-lighten-4">Além de você ter acesso ao curso completo com todos os assuntos separados da melhor forma possível, também será possível acessar dicas desenvolvidos pelos membros da equipe bilingual, e em breve pelos membros normais cadastrados. E o mais importante: nosso curso oferece um conteúdo completo e organizado do básico ao avançado. Saiba a verdadeira forma de aprender inglês do ZERO.</p>
      </div>
      <div class="col l4 offset-l2 s12">
        <h5 class="white-text">Nos siga no instagram ou entre em contato por e-mail</h5>
        <a href="https://www.instagram.com/bilingual.br/" target="_blank"><img style="width: 80px;"src="../img/instagram.png"></a>
        <a href="#"><i class="large white-text material-icons">email</i></a>
      </div>
    </div>
  </div>
  <div class="footer-copyright">
    <div class="container">
      © 2020 Bilingual
    </div>
  </div>
</footer>