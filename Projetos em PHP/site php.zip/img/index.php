<?php
	header('location: ../index');
?>