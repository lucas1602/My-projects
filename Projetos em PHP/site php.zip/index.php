<!DOCTYPE html>
<html lang="pt-br">
<head>
  <script data-ad-client="ca-pub-9871217803035137" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <title>Bilingual - Aprender inglês nunca foi tão fácil</title>
  <link rel="shortcut icon" href="img/fav.png">
  <!--Metas-->
  <meta charset="utf-8">
  <meta name="description" content="O melhor site para aprender inglês do básico ao avançado com os conteúdos 100% organizados">
  <meta name="author" content="Lucas Alan, Bilingual">
  <meta name="keywords" content="inglês, inglês básico, inglês avançado, inglês intermediário, curso de inglês, dicas de inglês, fluente em inglês, bilingual, como aprender inglês, aprender inglês com música, aprender inglês com séries, aprender inglês, inglês fácil, inglês para trabalho, inglês completo">
  <meta name="robots" content="index,nofollow">
  <meta name="format-detection" content="telephone=no">

  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <!--Customização-->
  <link rel="stylesheet" href="css/custom.css">
  <!-- Fontes -->
  <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap" rel="stylesheet">
</head>

<body>
  <!-- C A B E Ç A L H O -->
  <div class="navbar-fixed">
    <nav class="red darken-4">
      <div class="container">
        <div class="nav-wrapper">
          <a href="#" class="brand-logo center">Bilingual</a>
        </div>
      </div>
    </nav>
  </div>
  <!-- C O N T E Ú D O -->
  
  <!-- Modal Structure -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <p>   O site foi criado com o intuito de ajudar os amigos a aprenderem inglês, então está em uma hospedagem gratuíta e com domínio gratuíto. Qualquer tentativa de bugar ou atacar o site, tudo bem, você só estará arruinando o aprendizado de outra pessoa :).</p>
    </div>
    <div class="modal-footer">
      <a href="pages/curso.php" class="modal-close waves-effect waves-green btn-flat red darken-2 white-text">TUDO CERTO, IR PARA O SITE</a>
    </div>
  </div>
  
  <!--SLIDER-->
  <div class="slider">
    <ul class="slides">
      <li>
        <img src="img/slider1.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3 class="white light red-text text-lighten-1">Aulas e dicas</h3>
          <h5 class="white light red-text text-lighten-1">Curso 100% organizado da melhor forma para você
          </h5>
          <a href="#modal1" class="light btn-large waves-effect waves-light red lighten-2 botao modal-trigger">
            <i class="material-icons right">navigate_next</i>
            INICIAR AGORA MESMO
          </a>
        </div>
      </li>
      <li>
        <img src="img/slider5.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3 class="white light red-text text-lighten-1">Aprender inglês nunca foi tão fácil</h3>
          <h5 class="white light red-text text-lighten-1">Inglês para todas as idades
          </h5>
          <a href="#modal1" class="light btn-large waves-effect waves-light red lighten-2 botao modal-trigger">
            <i class="material-icons right">navigate_next</i>
            INICIAR AGORA MESMO
          </a>
        </div>
      </li>
    </ul>
  </div>
  <!-- DESCRICAO -->
  <hr>
  <div class="descricao row container">
    <section class="col s12 m12 l8">
      <div class="section white">
        <div class="row container">
          <h2 class="header red-text text-darken-4 light">Você sabia?</h2>
          <h3 class="light grey-text lighten-3">95% da população brasileira NÃO fala inglês</h3>
          <p class="light">Apesar de ser um dos idiomas mais simples do mundo, uma pesquisa feita pela British Council, afirma que apenas 5% da população brasileira sabe se comunicar em inglês.</p>
          <p class="light">Entre na nossa comunidade, aprenda inglês da melhor forma possível e seja incluso nessa minoria!</p>
        </div>
      </div>
    </section>
    <!--ASIDE-->
    <aside class="descricao col s12 m12 l4">
        <a href="#modal1" class="btn-large waves-effect waves-light red lighten-1 botao2 modal-trigger">
          Inglês do ZERO!
        </a>
    </aside>
  </div>
  <hr>
  <!-- R O D A P É -->
  <?php 
    include 'rodapeinicial.php';
  ?>

  <!--Jquery-->
  <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
    crossorigin="anonymous"></script>
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <!--Inicializações-->
  <script>
    $(document).ready(function () {
      //slider
      $('.slider').slider({
        indicators: false,
        height: 550,
        duration: 800,
        interval: 3500
      });
      //cards
      $('.tabs').tabs({
        duration: 500,
        swipable: true,
      });
      //select
      $('select').formSelect();
      //odal
      $('.modal').modal();
    });
  </script>
</body>

</html>