<?php

class CRUD {
	//curso
	public function readposts() {
		$sql = 'SELECT * FROM curso';

		$stmt = Conexao::getConn()->prepare($sql);
		$stmt->execute();

		if($stmt->rowCount() > 0):
			$resultado = $stmt->fetchAll(\PDO::FETCH_ASSOC);
			return $resultado;
		else:
			return [];
		endif;
	}
	//nlinhas de curso
	public function nlinhas() {
		$sql = 'SELECT * FROM curso';

		$stmt = Conexao::getConn()->prepare($sql);
		$stmt->execute();

		return $stmt->rowCount();
	}
	//nlinhas de dicas
	public function nlinhasd() {
		$sql = 'SELECT * FROM dicas';

		$stmt = Conexao::getConn()->prepare($sql);
		$stmt->execute();

		return $stmt->rowCount();
	}
	//dicas
	public function readblogs() {
		$sql = 'SELECT * FROM dicas';

		$stmt = Conexao::getConn()->prepare($sql);
		$stmt->execute();

		if($stmt->rowCount() > 0):
			$resultado = $stmt->fetchAll(\PDO::FETCH_ASSOC);
			return $resultado;
		else:
			return [];
		endif;
	}
	
	//visu curso
	public function addvisu($id, $visu){
		$sql= "UPDATE curso SET visu = :v WHERE id = :id";
		
		$stmt = Conexao::getConn()->prepare($sql);
		$stmt->bindValue(":v", $visu);
		$stmt->bindValue(":id", $id);
		$stmt->execute();
	}
	//visu dica
	public function addvisudicas($id, $visu){
		$sql= "UPDATE dicas SET visu = :v WHERE id = :id";
		
		$stmt = Conexao::getConn()->prepare($sql);
		$stmt->bindValue(":v", $visu);
		$stmt->bindValue(":id", $id);
		$stmt->execute();
	}
}

?>