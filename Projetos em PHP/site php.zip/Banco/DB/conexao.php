<?php

class Conexao {
	private static $instance;

	public static function getConn() {
		if(!isset(self::$instance)):
			self::$instance = new \PDO('mysql:host=localhost;dbname=id15431051_curso;charset=utf8','id15431051_lucas1602','@L92050779@l');
		endif;
		return self::$instance;
	}
}